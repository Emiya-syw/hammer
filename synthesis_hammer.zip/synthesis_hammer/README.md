## 合成大西瓜
- minprogram文件夹：小程序版本
- h5文件夹：网页版（作弊模式，点击右上角宝箱可切换水果）
- 其余文件（夹）均为原版源码
  - `default`为原版源码,也可以直接clone
  - `git clone -b default https://github.com/melodyjerry/synthesis_watermelon.git`

